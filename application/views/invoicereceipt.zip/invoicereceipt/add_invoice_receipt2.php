    <?php 
$this->load->view("includes/header");
$this->load->view("includes/sidebar");

$Company = '<select name="ReferenceId" id="ReferenceId" style="width:215px;" class="form-control select2">';
$Company .= '<option value="">Select Company</option>';
foreach ($AllReferences as $ReferenceRecord) {
$Company .=  '<option value='.$ReferenceRecord['ReferenceId'].'>'.$ReferenceRecord['FullName'].'</option>';
}
$Company .= '</select>';
?>
<script src="<?php echo site_url();?>/lib/js/autocompletejs/jquery-ui.js"></script>
<link rel="stylesheet" href="<?php echo site_url();?>/lib/css/autocompletecss/jquery-ui.css"/>

 <div class="content-wrapper">
    <section class="content-header">
      <h1><i class="fa fa-book"></i>&nbsp;Add Invoice Receipt</h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <!-- form elements --> 
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title text-light-blue">Add Invoice Receipt</h3>
            </div>
      <?php echo "<font style=color:#00468E; font-weight:bold text-align:center;>".$this->session->flashdata('record_update')."</font>"; ?>
      <!-- /.box-header -->
      
      <form role="form" class="form-horizontal" id="SaleOrderForm" action='<?php echo base_url("InvoiceReceipt/SaveMultiInstallment") ?>' method="post">
      <div class="box-body">
       <div class="row invoice-info">
        <input type='hidden' name="ChartOfAccountId" class="form-control" id="ChartOfAccountId">
     

	    <div class="col-sm-3 invoice-col">
          <address>
            <address> 
            
              <strong>Customers Name:</strong><br>
              <select class="form-control select2" name="customer_name" id="customer_name" style="width:215px;" required="required">
                  <option value="">Select Customers Name</option>
                  <?php foreach($AllCustomers as $Customers){ ?>
              <option value="<?php echo $Customers['CustomerId']; ?>"><?php echo $Customers['CustomerName']; ?></option>
              <?php } ?>
              
              </select>
            </address>
          </address>
        </div>
        <div class="col-sm-3 invoice-col">
          <address>
            <address> 
            
              <strong>Department Name:</strong><br>
             <input type='text' name="area" class="form-control" id="department"  style='color:#008000'>
              
              </select>
            </address>
          </address>
        </div>

        

       
        </div>
      </div>      
      <div class="row">
        <div class="col-md-12">   
          <div class="box-body pad table-responsive">
        <strong><u>Due Invoices:</u></strong><br>
            <table id="GJ_EntriesTable" style="border: 1px; solid;" class="table table-bordered text-center">
              <thead>
               <tr style="background-color:#ECF9FF;">
	        <th></th>
	        <th>S.#</th>
          <th>Invoice No</th>
          <th>Invoice Date</th>
          <th>Invoice Amount</th>
          <th>I.Tax</th>
          <th>Stamp Duty </th>
          <th>GST</th>
          <th>late Payment AMt</th>
          <th>Other Expense Amt</th>
          <th>Total Deduction</th>
          <th>Cheque Amount</th>
          <th>Remaining Amount</th>
	       </tr>
	      </thead>
	      <tbody>
	          
	      </tbody>
            </table>
            
	    
          </div>
        </div>
      </div>
     <div class="box-body">
       <div class="row invoice-info">
        

	    <div class="col-sm-3 invoice-col">
          <address>
            <address> 
              <strong>Payment Type:</strong><br>
              <select name="payment_type" id="payment_type" class="form-control" required="required">
              <option value="" selected="selected">Select Payment Type</option>
              <option value="1">On Cash</option>
              <option value="2">On Bank</option>
          </select>
            </address>
          </address>
        </div>

         <div class="col-sm-3 invoice-col">
          <address>
            <address> 
              <strong>Bank Account:</strong><br>
              <select name="bank_account_id" id="bank_account_id" class="form-control" required="required">
              <option value="0">Select Bank Account</option>
                  <?php  foreach ($GetAllBankAccounts as $BankAccounts) { ?>
                  <option value="<?php echo $BankAccounts['AccountId'] . "-" .$BankAccounts['ChartOfAccountId']; ?>"><?php echo $BankAccounts['AccountTitle'] . " - " . $BankAccounts['AccountNumber'];  ?></option>
                  <?php
                  } ?>
          </select>
            </address>
          </address>
        </div>
        <div class="col-sm-3 invoice-col">
          <address>
            <address> 
              <strong>Instrument / Cheque no</strong><br>
              <input  class="form-control" type="text" name="slip_no">
            </address>
          </address>
        </div>
        <div class="col-sm-3 invoice-col">
          <address>
            <address> 
              <strong>Date</strong><br>
              <input type="date" class="form-control"  name="date">
            </address>
          </address>
        </div>

        <div class="col-sm-3 invoice-col">
          <address>
            <address> 
              <strong>Copy</strong><br>
              <input type="file" class="form-control"  name="copy">
            </address>
          </address>
        </div>

       
        </div>
      </div>
      <div class="box-body">
      <div class="row">
       <div class="col-md-12">
         <div class="form-group">
           <label for="Note" class="col-sm-2 control-label">Note:</label>
             <div class="input-group">
               <textarea name="Note" class="form-control" rows="2" cols="60"></textarea>
             </div>
         </div>
       </div>
       <div class="col-md-2">
	<button type="submit" name="submitForm" value="AddRecord" class="btn btn-block btn-primary">Add Record</button>
       </div>
       <div class="col-md-2">
         <a href="<?php echo base_url(); ?>GeneralJournal/"><button type="button" name="cancelForm" value="cancelSave" class="btn btn-block bg-primary">Back to main</button></a>
       </div>
       
 
      </div>
      <!-- /.row -->
      </div>   
      </form>
      </div>
    </div>
   </div>
   </section>
   </div>

<script>

$('#customer_name').on('change', function() {
 
   var customer_name = this.value;
    $.ajax({
        type: 'POST',
        dataType: 'html',
        data: {customer_name:customer_name},
        url: "<?php echo base_url('InvoiceReceipt/AutoMultiCompleteSearch_COA'); ?>",
        success: function(response){
          var payObject = JSON.parse(response);
          $("tbody").html('');
          var a=1
          payObject.forEach(myFunction);
            function myFunction(item, index) {
     
            var row='';
        row+= "<tr id='row_"+index+"'>";
	    row += "<td><input type='checkbox'   name='tick[]' data-id='"+index+"'   value='"+item.SaleId+"' id='tick' onclick='checkbox("+index+")' class='tick'></td>";
		row+= "<td>"+a+"</td>";
		row+= "<td><input style='width:100%; text-align:left;' type='text'name='invoice_no["+item.SaleId+"]' id='Invoiceno_"+index+"' value='"+item.UniqueId+"' /></td>";
		row+= "<td><input style='width:100%; text-align:left;' type='text' name='Invoicedate["+item.SaleId+"]' id='Invoicedate_"+index+"'  value='"+item.SaleDate+"'/></td>";
		row+= "<td><input style='width:100%; text-align:left;color:purple' type='text' name='outstanding_amount["+item.SaleId+"]' id='Invoiceamount_"+index+"'   value='"+item.PreviousBalance+"'/></td>";
		row+= "<td><input style='width:100%; text-align:left;' onkeyup='inputbtn("+index+")' type='text' value='0' name='Itax["+item.SaleId+"]' id='Itax_"+index+"' autocomplete='off'/></td>";
		row+= "<td><input style='width:100%; text-align:left;' onkeyup='inputbtn("+index+")' type='text' value='0' name='Stampduty["+item.SaleId+"]' id='Stampduty_"+index+"' autocomplete='off'/></td>";
		row+= "<td><input style='width:100%; text-align:left;' onkeyup='inputbtn("+index+")'type='text' value='0' name='Gst["+item.SaleId+"]' id='Gst_"+index+"' autocomplete='off'/></td>";
		row+= "<td><input style='width:100%; text-align:left;' onkeyup='inputbtn("+index+")'type='text' value='0' name='LatePayment["+item.SaleId+"]' id='latepayment_"+index+"' autocomplete='off'/></td>";
		row+= "<td><input style='width:100%; text-align:left;' onkeyup='inputbtn("+index+")'type='text'value='0'  name='OtherExp["+item.SaleId+"]' id='Otherexpense_"+index+"' autocomplete='off'/></td>";
	    row+= "<td><input style='width:100%; text-align:left;color:#008000' onkeyup='inputbtn("+index+")'type='text' value='0' name='remarks["+item.SaleId+"]'  id='Totaldeduction_"+index+"' autocomplete='off'/></td>";
		row+= "<td><input style='width:100%; text-align:left;color:#002480' type='text' name='amount["+item.SaleId+"]'onkeyup='checkbtn("+index+")'   id='Chequeamount_"+index+"' value='"+item.PreviousBalance+"' /></td>";
		row+= "<td><input style='width:100%; text-align:left;color:#dd4b39' onkeyup='inputbtn("+index+")' type='text'  name='Remainingamount["+item.SaleId+"]' id='Remainingamount_"+index+"' value='"+item.PreviousBalance+"'/></td>";
	    row+= "</tr>";
	    a++;
	    $("#GJ_EntriesTable").append(row);
	    
	    $('#department').val(item.AreaName);
	     $('#ChartOfAccountId').val(item.ChartOfAccountId);
            }
             var row='';
         row+= "<tr >";
	    row+= "<td></td>";
	    row+= "<td></td>";
		row+= "<td></td>";
		row+= "<td></td>";
		row+= "<td id='totInvoiceamount' style='color:purple'></td>";
		row+= "<td id='totItax'></td>";
		row+= "<td id='totStampduty'></td>";
		row+= "<td id='totGst'></td>";
		row+= "<td id='totlatepayment'></td>";
		row+= "<td id='tototherExpense'></td>";
		row+= "<td id='totTotaldeduction'  style='color:#008000'></td>";
		row+= "<td id='totChequeamount' style='color:#002480'></td>";
		row+= "<td id='totRemainingamount' style='color:#dd4b39'></td>";
		row+= "</tr>"
        $("#GJ_EntriesTable").append(row);
        //  $("#customer_name").val(payObject[0].CustomerName);
        //  $("#client_id").val(payObject[0].CustomerId);
        //  $("#ChartOfAccountId").val(payObject[0].ChartOfAccountId);
        //  $("#area").val(payObject[0].AreaName);
        //  $("#outstanding_amount").val(payObject[0].PreviousBalance);
        }
      });
    
    
    
});
function checkbtn(id){
      Invoiceamount=parseInt($('#Invoiceamount_'+id).val());
      totChequeamount= $('#Chequeamount_'+id).val();
       totRemainingamount=$('#Totaldeduction_'+id).val();
       Remainingamount=Invoiceamount-totChequeamount-totRemainingamount;
       parseInt($('#Remainingamount_'+id).val(Remainingamount));
}
function inputbtn(id){
// $( "input" ).on( "keyup", function() {
// $("input").keyup(function(){
   

            // id=$(this).val();
            tottax=0;
            Invoiceamount=parseInt($('#Invoiceamount_'+id).val());
            totItax=parseInt($('#Itax_'+id).val());
            totStampduty=parseInt($('#Stampduty_'+id).val());
            totGst=parseInt($('#Gst_'+id).val());
            totlatepayment=parseInt($('#latepayment_'+id).val());
            totTotaldeduction=parseInt($('#Totaldeduction_'+id).val());
            tototherExpense=parseInt($('#Otherexpense_'+id).val());
            
            // totItax=parseInt(totItax)*parseInt(Invoiceamount)/100;
            // totStampduty=parseInt(totStampduty)*parseInt(Invoiceamount)/100;
            // totGst=parseInt(totGst)*parseInt(Invoiceamount)/100;
            
            tottax=parseInt(totItax)+parseInt(totStampduty)+parseInt(totGst)+parseInt(totlatepayment)+parseInt(tototherExpense)
            totChequeamount=Invoiceamount-tottax;
            $('#Chequeamount_'+id).val(totChequeamount);
            Remainingamount=Invoiceamount-tottax-totChequeamount;
           
             parseInt($('#Totaldeduction_'+id).val(tottax));
             parseInt($('#Remainingamount_'+id).val(Remainingamount));
          checkbox();
       
};

  function checkbox(id){
      
   Invoiceamount=0;
    totItax=0;
    totStampduty=0;
    totGst=0;
    totlatepayment=0;
    totTotaldeduction=0;
    tototherExpense=0;
     totRemainingamount=0;
     totChequeamount=0;
    
    $('.tick').each(function () {
        if (this.checked) {
            id=$(this).data("id");
            
            Invoiceamount+=parseInt($('#Invoiceamount_'+id).val());
            console.log(Invoiceamount);
            console.log();
            totItax+=parseInt($('#Itax_'+id).val());
            totStampduty+=parseInt($('#Stampduty_'+id).val());
            totGst+=parseInt($('#Gst_'+id).val());
            totlatepayment+=parseInt($('#latepayment_'+id).val());
            totTotaldeduction+=parseInt($('#Totaldeduction_'+id).val());
            tototherExpense+=parseInt($('#Otherexpense_'+id).val());
             totChequeamount+=parseInt($('#Chequeamount_'+id).val());
              totRemainingamount+=parseInt($('#Remainingamount_'+id).val());
          
        }
    });
    $('#totInvoiceamount').html(Invoiceamount)
    $('#totItax').html(totItax)
    $('#totStampduty').html(totStampduty)
    $('#totGst').html(totGst)
    $('#totlatepayment').html(totlatepayment)
    $('#totTotaldeduction').html(totTotaldeduction)
    $('#tototherExpense').html(tototherExpense)
    $('#totChequeamount').html(totChequeamount)
    $('#totRemainingamount').html(totRemainingamount)
  };
  </script>
<?php  $this->load->view("includes/footer"); ?> 