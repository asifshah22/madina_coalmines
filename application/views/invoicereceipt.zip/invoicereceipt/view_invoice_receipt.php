<?php $this->load->view('includes/header'); ?>
<?php $this->load->view('includes/sidebar'); ?>

      <!-- /.main-content starts -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1><i class="fa fa-book"></i>&nbsp;Invoice Receipt</h1>
    </section>
    
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title text-light-blue">View Invoice Receipt</h3>
            </div>
  <?php echo "<font style=color:#00468E; font-weight:bold text-align:center;>".$this->session->flashdata('record_update')."</font>"; ?>
  <?php echo "<font style=color:#00468E; font-weight:bold text-align:center;>".$this->session->flashdata('record_deleted')."</font>"; ?>
  
  <form role="form" class="form-horizontal" id="SaleOrderForm" action='<?php echo base_url("Sales/SaveSale") ?>' method="post">
  <div class="box-body">
      
    <div class="form-group">
      <label for="ProductName" class="col-sm-1 control-label">Invoice Receipt #</label>
      <div class="col-sm-4">
      <?php echo $GetInvoiceReceipt['GeneralJournal']->GeneralJournalId; ?>
      </div>
    </div>

    <div class="form-group">
      <label for="ProductName" class="col-sm-1 control-label">Date</label>
      <div class="col-sm-4">
      <?php echo date('M d, Y', strtotime($GetInvoiceReceipt['GeneralJournal']->TransactionDate)); ?>
      </div>
    </div>

      <div class="form-group">
        <label for="ProductName" class="col-sm-1 control-label">Invoice No</label>
        <div class="col-sm-4">
        <?php echo $GetInvoiceReceipt['GeneralJournal']->SaleUniqueId; ?>
        </div>
      </div>

      <div class="form-group">
        <label for="ProductName" class="col-sm-1 control-label">Customer Name</label>
        <div class="col-sm-4">
         <p style="color: #002480;font-weight:bold;"> <?php echo $GetInvoiceReceipt['GeneralJournal']->CustomerName; ?> </p>
        </div>
      </div>

      <div class="form-group">
        <label for="ProductName" class="col-sm-1 control-label">Department</label>
        <div class="col-sm-4">
          <p style="color: #008000;font-weight:bold;"><?php echo $GetInvoiceReceipt['GeneralJournal']->Area_name; ?> </p>
        </div>
      </div>

      <div class="form-group">
        <label for="ProductName" class="col-sm-1 control-label">Payment Type</label>
        <div class="col-sm-4">
          <?php if($GetInvoiceReceipt['GeneralJournal']->VoucherType == 3){ echo "On Cash" ; }
              else if($GetInvoiceReceipt['GeneralJournal']->VoucherType == 2){ echo "On Bank" ; }
              else{ echo 'No Type Selected';  } ?>
        </div>
      </div>

      <div class="form-group">
        <label for="BankAccount" class="col-sm-1 control-label">Bank Account</label>
        <div class="col-sm-4">
          <?php echo $GetInvoiceReceipt['GeneralJournal']->BankName;  ?>
            
        </div>
      </div>

      <div class="form-group">
        <label for="ProductName" class="col-sm-1 control-label">Instrument / Cheque no</label>
        <div class="col-sm-4">
        <?php echo $GetInvoiceReceipt['GeneralJournal']->ReceiptNo;  ?>
        </div>
      </div>
         <div class="form-group">
        <label for="ProductName" class="col-sm-1 control-label">Receipt Amount</label>
        <div class="col-sm-4">
        <?php echo $GetInvoiceReceipt['GeneralJournal']->TotalDebit;  ?>
        </div>
      </div>
      <div class="form-group">
        <label for="ProductName" class="col-sm-1 control-label">Gst</label>
        <div class="col-sm-4">
        <?php echo $GetInvoiceReceipt['GeneralJournal']->gst;  ?>
        </div>
      </div>

      <div class="form-group">
        <label for="ProductName" class="col-sm-1 control-label">Stamp Duty</label>
        <div class="col-sm-4">
        <?php echo $GetInvoiceReceipt['GeneralJournal']->stampduty;  ?>
        </div>
      </div>
       

      <div class="form-group">
        <label for="ProductName" class="col-sm-1 control-label">Other Exp</label>
        <div class="col-sm-4">
        <?php echo $GetInvoiceReceipt['GeneralJournal']->OtherExp;  ?>
        </div>
      </div>

      <div class="form-group">
        <label for="ProductName" class="col-sm-1 control-label">Late Payment</label>
        <div class="col-sm-4">
        <?php echo $GetInvoiceReceipt['GeneralJournal']->LatePayment;  ?>
        </div>
      </div>

      <div class="form-group">
        <label for="ProductName" class="col-sm-1 control-label">Tax Deduction</label>
        <div class="col-sm-4">
        <?php echo $GetInvoiceReceipt['GeneralJournal']->itax;  ?>
        </div>
      </div>
       <div class="form-group">
        <label for="ProductName" class="col-sm-1 control-label">Total Deduction</label>
        <div class="col-sm-4">
        <?php echo $GetInvoiceReceipt['GeneralJournal']->Detail;  ?>
        </div>
      </div>

</div>
      			 
  </form>
  <div class="col-md-12">&nbsp;</div>
        
  <div class="box-footer">
    <div class="col-md-12">
      <a href="<?php echo base_url(); ?>InvoiceReceipt/AddInvoiceReceipt"><button type="button" class="btn btn-primary pull-left" style="color:white; margin-right:5px;"> Add Record </button></a>
      <a href="<?php echo base_url(); ?>InvoiceReceipt/"><button type="button" class="btn bg-primary pull-left" style="color:white; margin-right:5px;">Back to Main</button></a>
    </div>
  </div> 

<?php $this->load->view("includes/footer"); ?>
